package com.example.spot.offline

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.example.spot.R
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth

/** Visible pending/error state; never label locally saved data as server-synced. */
object SyncStatusView {
    fun attach(activity: Activity) {
        val label = activity.findViewById<TextView>(R.id.tvSyncStatus)
        val handler = Handler(Looper.getMainLooper())
        var stopped = false
        var entries = emptyList<OfflineStore.Entry>()
        val refresh = object : Runnable {
            override fun run() {
                if (stopped || activity.isDestroyed || activity.isFinishing) return
                val uid = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
                Tasks.call(OfflinePatrol.io) { OfflineStore.get(activity).entries(uid) }
                    .addOnSuccessListener { current ->
                        if (stopped) return@addOnSuccessListener
                        entries = current
                        val pending = current.count { it.error == null }
                        val errors = current.size - pending
                        val network = if (OfflinePatrol.online(activity)) "Online" else "Offline"
                        label.text = when {
                            errors > 0 -> "$network · $pending pending · $errors need attention — tap to review"
                            pending > 0 -> "$network · $pending actions saved on this phone, waiting to sync"
                            else -> "$network · No pending patrol actions"
                        }
                    }.addOnCompleteListener {
                        if (!stopped) handler.postDelayed(this, 3000)
                    }
            }
        }
        label.setOnClickListener {
            val errors = entries.filter { it.error != null }
            AlertDialog.Builder(activity).setTitle("Patrol sync")
                .setMessage(if (errors.isEmpty()) "${entries.size} saved actions waiting to sync. Sync runs automatically when internet is available. Keep this app's data until syncing completes."
                    else errors.take(10).joinToString("\n\n") { "${it.kind}: ${it.error}" })
                .setPositiveButton("Retry") { _, _ ->
                    val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return@setPositiveButton
                    Tasks.call(OfflinePatrol.io) {
                        OfflineStore.get(activity).retry(uid)
                        OfflinePatrol.schedule(activity)
                    }
                }.setNegativeButton("Close", null).show()
        }
        label.addOnAttachStateChangeListener(object : android.view.View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(view: android.view.View) { stopped = false; handler.post(refresh) }
            override fun onViewDetachedFromWindow(view: android.view.View) { stopped = true; handler.removeCallbacks(refresh) }
        })
        if (label.isAttachedToWindow) handler.post(refresh)
        OfflinePatrol.schedule(activity)
    }
}
