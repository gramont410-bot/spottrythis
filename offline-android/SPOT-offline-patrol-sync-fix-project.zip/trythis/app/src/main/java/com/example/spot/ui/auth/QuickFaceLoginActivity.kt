package com.example.spot.ui.auth

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.spot.R
import com.example.spot.ui.guard.GuardDashboardActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class QuickFaceLoginActivity : AppCompatActivity() {

    private lateinit var cameraExecutor: ExecutorService
    private lateinit var viewFinder: PreviewView
    private lateinit var tvInstructions: TextView
    private lateinit var tvLivenessStatus: TextView
    private lateinit var viewFillLight: View
    private lateinit var btnToggleLight: ImageButton

    private lateinit var faceDetector: FaceDetector

    private var isVerified = false
    private val registeredGuards = mutableListOf<GuardFaceInfo>()
    private val CAMERA_PERMISSION_CODE = 2002

    // Liveness State
    private var hasBlinked = false
    private var hasSmiled = false
    private var eyesWereOpen = false
    private var isFillLightOn = false
    private var consecutiveMatchCount = 0

    data class GuardFaceInfo(
        val id: String,
        val name: String,
        val siteId: String,
        val embedding: List<Double>
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_face_verify)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        viewFinder = findViewById(R.id.viewFinder)
        tvInstructions = findViewById(R.id.tvInstructions)
        tvLivenessStatus = findViewById(R.id.tvLivenessStatus)
        viewFillLight = findViewById(R.id.viewFillLight)
        btnToggleLight = findViewById(R.id.btnToggleLight)
        
        cameraExecutor = Executors.newSingleThreadExecutor()
        faceDetector = FaceDetection.getClient(FaceRecognitionUtils.detectorOptions())

        tvInstructions.text = "Quick Face Login"
        tvLivenessStatus.text = "Align face in guide"

        btnToggleLight.setOnClickListener { toggleFillLight() }

        loadAllGuardsForFastRecognition { success ->
            if (success) {
                if (checkCameraPermission()) startCamera()
                else requestCameraPermission()
            } else {
                Toast.makeText(this, "Failed to connect to database.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun toggleFillLight() {
        isFillLightOn = !isFillLightOn
        viewFillLight.visibility = if (isFillLightOn) View.VISIBLE else View.GONE
        val lp = window.attributes
        lp.screenBrightness = if (isFillLightOn) 1.0f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
    }

    private fun loadAllGuardsForFastRecognition(callback: (Boolean) -> Unit) {
        FirebaseFirestore.getInstance().collection("users")
            .whereEqualTo("role", "guard")
            .get()
            .addOnSuccessListener { result ->
                registeredGuards.clear()
                for (doc in result) {
                    val rawEmb = doc.get("faceEmbedding") as? List<*>
                    if (rawEmb != null && rawEmb.isNotEmpty()) {
                        registeredGuards.add(GuardFaceInfo(
                            doc.id,
                            doc.getString("fullName") ?: "Guard",
                            doc.getString("assignedSiteId") ?: "",
                            rawEmb.map { (it as Number).toDouble() }
                        ))
                    }
                }
                callback(true)
            }
            .addOnFailureListener { callback(false) }
    }

    private fun checkCameraPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(viewFinder.surfaceProvider) }
            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            imageAnalyzer.setAnalyzer(cameraExecutor) { imageProxy ->
                processLiveFace(imageProxy)
            }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, imageAnalyzer)
            } catch (e: Exception) {
                Toast.makeText(this, "Camera error.", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @OptIn(ExperimentalGetImage::class)
    private fun processLiveFace(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null && !isVerified) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            
            faceDetector.process(image)
                .addOnSuccessListener { faces ->
                    if (faces.isNotEmpty()) {
                        val face = faces[0]
                        val faceRatio = face.boundingBox.width().toFloat() / mediaImage.height.toFloat()
                        
                        val quality = FaceRecognitionUtils.checkQuality(face, faceRatio)
                        if (quality.ok) {
                            checkLiveness(face)
                            val liveEmbedding = FaceRecognitionUtils.extractEmbedding(face)
                            
                            if (liveEmbedding != null) {
                                var bestMatchGuard: GuardFaceInfo? = null
                                var lowestDistance = Double.MAX_VALUE

                                for (guard in registeredGuards) {
                                    val distance = FaceRecognitionUtils.distance(liveEmbedding, guard.embedding)
                                    if (distance < FaceRecognitionUtils.MATCH_THRESHOLD && distance < lowestDistance) {
                                        lowestDistance = distance
                                        bestMatchGuard = guard
                                    }
                                }

                                if (bestMatchGuard != null) {
                                    consecutiveMatchCount++
                                    
                                    runOnUiThread { updateLivenessUI() }

                                    if (consecutiveMatchCount >= FaceRecognitionUtils.REQUIRED_MATCHES && hasBlinked && hasSmiled) {
                                        isVerified = true
                                        runOnUiThread {
                                            Toast.makeText(this, "Welcome, ${bestMatchGuard.name}", Toast.LENGTH_SHORT).show()
                                            saveUserSession(bestMatchGuard.id, "guard", bestMatchGuard.name, bestMatchGuard.siteId)
                                            recordAttendanceAndLogin(bestMatchGuard.id, bestMatchGuard.name, bestMatchGuard.siteId)
                                        }
                                    }
                                } else {
                                    consecutiveMatchCount = 0
                                    runOnUiThread { 
                                        tvLivenessStatus.text = "Unknown Face" 
                                        tvLivenessStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
                                    }
                                }
                            }
                        } else {
                            runOnUiThread { 
                                tvLivenessStatus.text = quality.message 
                                tvLivenessStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark))
                            }
                        }
                    } else {
                        runOnUiThread { tvLivenessStatus.text = "Searching for face..." }
                    }
                }
                .addOnCompleteListener { imageProxy.close() }
        } else imageProxy.close()
    }

    private fun checkLiveness(face: Face) {
        val blinkResult = FaceRecognitionUtils.isBlinkDetected(face, eyesWereOpen)
        eyesWereOpen = blinkResult.nextEyesWereOpen
        if (blinkResult.detected) hasBlinked = true
        if (FaceRecognitionUtils.isSmiling(face)) hasSmiled = true
    }

    private fun updateLivenessUI() {
        when {
            !hasBlinked -> {
                tvLivenessStatus.text = "Liveness: Please Blink"
                tvLivenessStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_blue_light))
            }
            !hasSmiled -> {
                tvLivenessStatus.text = "Liveness: Now Smile"
                tvLivenessStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
            }
            else -> {
                tvLivenessStatus.text = "Verifying Identity..."
                tvLivenessStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
            }
        }
    }

    private fun saveUserSession(userId: String, role: String, name: String, siteId: String) {
        val sharedPref = getSharedPreferences("SPOT_SESSION", Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        with(sharedPref.edit()) {
            putString("USER_ID", userId)
            putString("USER_ROLE", role)
            putString("USER_NAME", name)
            putString("SITE_ID", siteId)
            putString("SESSION_DATE", today)
            putBoolean("IS_LOGGED_IN", true)
            apply()
        }
    }

    private fun recordAttendanceAndLogin(guardId: String, guardName: String, siteId: String) {
        val db = FirebaseFirestore.getInstance()
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

        val attendanceData = mapOf(
            "guardId" to guardId, "guardName" to guardName, "siteId" to siteId,
            "date" to today, "timeIn" to timeNow, "status" to "ON_DUTY"
        )

        db.collection("attendance").add(attendanceData)
            .addOnSuccessListener { ref ->
                val sharedPref = getSharedPreferences("SPOT_SESSION", Context.MODE_PRIVATE)
                sharedPref.edit().putString("CURRENT_SHIFT_ID", ref.id).apply()
                
                val intent = Intent(this, GuardDashboardActivity::class.java).apply {
                    putExtra("GUARD_ID", guardId)
                    putExtra("GUARD_NAME", guardName)
                    putExtra("ASSIGNED_SITE_ID", siteId)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                startActivity(intent)
                finish()
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        faceDetector.close()
        cameraExecutor.shutdown()
    }
}
